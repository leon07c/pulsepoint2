import React from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

export default function PatientInput({ inputValue, setInputValue, fetchPatientData }) {
  return (
    <div className="mb-6">
      <Input
        value={inputValue}
        onChange={(e) => setInputValue(e.target.value)}
        placeholder="Enter patient ID, driver's license, or scan biometric..."
      />
      <Button onClick={fetchPatientData} className="mt-2">Access Patient</Button>
    </div>
  );
}
